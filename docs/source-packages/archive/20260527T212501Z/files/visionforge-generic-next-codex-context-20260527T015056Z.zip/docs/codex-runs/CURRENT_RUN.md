# Current Codex Run

Current run: `P30`
Updated UTC: `2026-05-22T06:41:05Z`

Historical run material in `docs/codex-runs/archive/` is evidence, not active instruction.
