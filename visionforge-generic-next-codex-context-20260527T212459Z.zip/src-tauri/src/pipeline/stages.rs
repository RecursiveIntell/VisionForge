use anyhow::{Context, Result};
use reqwest::Client;
use serde_json::Value;
use std::time::Instant;

use crate::pipeline::ollama::{self, ChatMessage};
use crate::pipeline::prompts::{self, CheckpointContext};
use crate::types::pipeline::{
    ComposerOutput, IdeatorOutput, JudgeOutput, JudgeRanking, PromptEngineerOutput, PromptPair,
    ReviewerOutput,
};

pub async fn run_ideator(
    client: &Client,
    endpoint: &str,
    model: &str,
    idea: &str,
    num_concepts: u32,
    think: Option<bool>,
) -> Result<IdeatorOutput> {
    let start = Instant::now();
    let (system, user) = prompts::ideator_prompt(idea, num_concepts);

    let messages = vec![
        ChatMessage {
            role: "system".to_string(),
            content: system,
        },
        ChatMessage {
            role: "user".to_string(),
            content: user,
        },
    ];

    let resp = ollama::chat_with_options(
        client,
        endpoint,
        model,
        &messages,
        false,
        &ollama::stage_options_with_thinking(1024, think),
    )
    .await
    .context("Ideator stage failed")?;

    let concepts = parse_numbered_list(&resp.content);
    if concepts.is_empty() {
        anyhow::bail!(
            "Ideator returned no concepts. Raw response: {}",
            &resp.content[..resp.content.len().min(200)]
        );
    }

    Ok(IdeatorOutput {
        input: idea.to_string(),
        output: concepts,
        duration_ms: start.elapsed().as_millis() as u64,
        model: model.to_string(),
        tokens_in: resp.prompt_eval_count,
        tokens_out: resp.eval_count,
    })
}

pub async fn run_composer(
    client: &Client,
    endpoint: &str,
    model: &str,
    concept: &str,
    concept_index: usize,
    think: Option<bool>,
) -> Result<ComposerOutput> {
    let start = Instant::now();
    let (system, user) = prompts::composer_prompt(concept);

    let messages = vec![
        ChatMessage {
            role: "system".to_string(),
            content: system,
        },
        ChatMessage {
            role: "user".to_string(),
            content: user,
        },
    ];

    let resp = ollama::chat_with_options(
        client,
        endpoint,
        model,
        &messages,
        false,
        &ollama::stage_options_with_thinking(2048, think),
    )
    .await
    .context("Composer stage failed")?;

    let output = resp.content.trim().to_string();
    if output.is_empty() {
        anyhow::bail!("Composer returned empty output for concept: {}", concept);
    }

    Ok(ComposerOutput {
        input_concept_index: concept_index,
        input: concept.to_string(),
        output,
        duration_ms: start.elapsed().as_millis() as u64,
        model: model.to_string(),
        tokens_in: resp.prompt_eval_count,
        tokens_out: resp.eval_count,
    })
}

pub async fn run_judge(
    client: &Client,
    endpoint: &str,
    model: &str,
    original_idea: &str,
    concepts: &[String],
    think: Option<bool>,
) -> Result<JudgeOutput> {
    let start = Instant::now();
    let (system, user) = prompts::judge_prompt(original_idea, concepts);

    let messages = vec![
        ChatMessage {
            role: "system".to_string(),
            content: system,
        },
        ChatMessage {
            role: "user".to_string(),
            content: user,
        },
    ];

    let resp = ollama::chat_with_options(
        client,
        endpoint,
        model,
        &messages,
        true,
        &ollama::stage_options_with_thinking(1024, think),
    )
    .await
    .context("Judge stage failed")?;

    let rankings =
        parse_judge_rankings(&resp.content).context("Failed to parse Judge output as rankings")?;

    if rankings.is_empty() {
        anyhow::bail!(
            "Judge returned no rankings. Raw response: {}",
            &resp.content[..resp.content.len().min(200)]
        );
    }

    let rankings = backfill_rankings(rankings, concepts.len());

    Ok(JudgeOutput {
        input: concepts.to_vec(),
        output: rankings,
        duration_ms: start.elapsed().as_millis() as u64,
        model: model.to_string(),
    })
}

pub async fn run_prompt_engineer(
    client: &Client,
    endpoint: &str,
    model: &str,
    description: &str,
    checkpoint_ctx: Option<CheckpointContext>,
    think: Option<bool>,
) -> Result<PromptEngineerOutput> {
    let start = Instant::now();
    let ctx = checkpoint_ctx.unwrap_or_default();
    let checkpoint_context_str = format!(
        "Checkpoint: {}, Base: {}, Strengths: {}, Weaknesses: {}",
        ctx.checkpoint_name, ctx.base_model, ctx.strengths, ctx.weaknesses
    );

    let (system, user) = prompts::prompt_engineer_prompt(description, &ctx);

    let messages = vec![
        ChatMessage {
            role: "system".to_string(),
            content: system,
        },
        ChatMessage {
            role: "user".to_string(),
            content: user,
        },
    ];

    let resp = ollama::chat_with_options(
        client,
        endpoint,
        model,
        &messages,
        true,
        &ollama::stage_options_with_thinking(1024, think),
    )
    .await
    .context("Prompt Engineer stage failed")?;

    let pair = parse_prompt_pair(&resp.content)
        .context("Failed to parse Prompt Engineer output as positive/negative pair")?;

    Ok(PromptEngineerOutput {
        input: description.to_string(),
        checkpoint_context: Some(checkpoint_context_str),
        output: pair,
        duration_ms: start.elapsed().as_millis() as u64,
        model: model.to_string(),
        tokens_in: resp.prompt_eval_count,
        tokens_out: resp.eval_count,
    })
}

pub async fn run_reviewer(
    client: &Client,
    endpoint: &str,
    model: &str,
    original_idea: &str,
    positive: &str,
    negative: &str,
    think: Option<bool>,
) -> Result<ReviewerOutput> {
    let start = Instant::now();
    let (system, user) = prompts::reviewer_prompt(original_idea, positive, negative);

    let messages = vec![
        ChatMessage {
            role: "system".to_string(),
            content: system,
        },
        ChatMessage {
            role: "user".to_string(),
            content: user,
        },
    ];

    let resp = ollama::chat_with_options(
        client,
        endpoint,
        model,
        &messages,
        true,
        &ollama::stage_options_with_thinking(1024, think),
    )
    .await
    .context("Reviewer stage failed")?;

    let output = parse_reviewer_output(&resp.content).context("Failed to parse Reviewer output")?;

    Ok(ReviewerOutput {
        approved: output.approved,
        issues: output.issues,
        suggested_positive: output.suggested_positive,
        suggested_negative: output.suggested_negative,
        duration_ms: start.elapsed().as_millis() as u64,
        model: model.to_string(),
    })
}

pub(super) fn parse_numbered_list(text: &str) -> Vec<String> {
    let mut concepts = Vec::new();
    let mut current = String::new();

    for line in text.lines() {
        let trimmed = line.trim();
        if trimmed.is_empty() {
            continue;
        }

        // Check if line starts a new numbered item (e.g., "1. ", "2. ", "1) ", "2) ")
        // Only match digits immediately followed by ". " or ") " at the start
        let prefix_end = trimmed
            .find(|c: char| !c.is_ascii_digit())
            .unwrap_or(trimmed.len());
        let after_digits = &trimmed[prefix_end..];
        let is_new_item =
            prefix_end > 0 && (after_digits.starts_with(". ") || after_digits.starts_with(") "));

        if is_new_item {
            if !current.is_empty() {
                concepts.push(current.trim().to_string());
            }
            // Strip the number prefix (digits + delimiter)
            let content = &trimmed[prefix_end + 2..];
            current = content.trim().to_string();
        } else {
            // Continuation of previous item
            if !current.is_empty() {
                current.push(' ');
            }
            current.push_str(trimmed);
        }
    }

    if !current.is_empty() {
        concepts.push(current.trim().to_string());
    }

    concepts
}

pub(super) fn parse_judge_rankings(text: &str) -> Result<Vec<JudgeRanking>> {
    let json = extract_json_from_text(text)?;

    // Handle bare arrays, objects wrapping an array, or a single ranking object
    let arr = if let Some(a) = json.as_array() {
        a.clone()
    } else if let Some(obj) = json.as_object() {
        // Check if this IS a single ranking object (has rank/score at top level)
        if obj.contains_key("rank") || obj.contains_key("score") {
            vec![json.clone()]
        } else {
            // Models often wrap the array in an object like {"ranked_concepts": [...]}
            obj.values()
                .find_map(|v| {
                    v.as_array().filter(|a| {
                        a.first()
                            .map(|item| item.get("rank").is_some() || item.get("score").is_some())
                            .unwrap_or(false)
                    })
                })
                .cloned()
                .context("Judge output is a JSON object but contains no ranking array")?
        }
    } else {
        anyhow::bail!("Judge output is neither a JSON array nor an object");
    };

    let mut rankings = Vec::new();
    for (i, item) in arr.iter().enumerate() {
        let rank = item
            .get("rank")
            .and_then(|v| v.as_u64())
            .map(|v| v as u32)
            .unwrap_or_else(|| (i + 1) as u32); // Default to position-based rank

        let concept_index = item
            .get("concept_index")
            .or_else(|| item.get("index"))
            .and_then(|v| v.as_u64())
            .unwrap_or(0) as usize;

        let score = item.get("score").and_then(|v| v.as_u64()).unwrap_or(0) as u32;

        let reasoning = item
            .get("reasoning")
            .or_else(|| item.get("reason"))
            .or_else(|| item.get("explanation"))
            .and_then(|v| v.as_str())
            .unwrap_or("")
            .to_string();

        rankings.push(JudgeRanking {
            rank,
            concept_index,
            score,
            reasoning,
        });
    }

    rankings.sort_by_key(|r| r.rank);
    Ok(rankings)
}

/// Backfill any missing concept indices so the judge output has one entry per concept.
/// Missing concepts get appended with a low score and placeholder reasoning.
pub(super) fn backfill_rankings(
    mut rankings: Vec<JudgeRanking>,
    num_concepts: usize,
) -> Vec<JudgeRanking> {
    let present: std::collections::HashSet<usize> =
        rankings.iter().map(|r| r.concept_index).collect();
    let max_rank = rankings.iter().map(|r| r.rank).max().unwrap_or(0);

    for i in 0..num_concepts {
        if !present.contains(&i) {
            rankings.push(JudgeRanking {
                rank: max_rank + 1 + (i as u32),
                concept_index: i,
                score: 0,
                reasoning: "(Not evaluated by judge)".to_string(),
            });
        }
    }

    rankings.sort_by_key(|r| r.rank);
    rankings
}

pub(super) fn parse_prompt_pair(text: &str) -> Result<PromptPair> {
    let json = extract_json_from_text(text)?;

    let positive = json
        .get("positive")
        .and_then(|v| v.as_str())
        .context("Missing 'positive' field in Prompt Engineer output")?
        .to_string();

    let negative = json
        .get("negative")
        .and_then(|v| v.as_str())
        .context("Missing 'negative' field in Prompt Engineer output")?
        .to_string();

    Ok(PromptPair { positive, negative })
}

pub(super) struct ParsedReviewer {
    pub(super) approved: bool,
    pub(super) issues: Option<Vec<String>>,
    pub(super) suggested_positive: Option<String>,
    pub(super) suggested_negative: Option<String>,
}

pub(super) fn parse_reviewer_output(text: &str) -> Result<ParsedReviewer> {
    let json = extract_json_from_text(text)?;

    let approved = json
        .get("approved")
        .and_then(|v| v.as_bool())
        .unwrap_or(true); // Default to approved if parsing fails

    let issues = json.get("issues").and_then(|v| {
        v.as_array().map(|arr| {
            arr.iter()
                .filter_map(|item| item.as_str().map(String::from))
                .collect()
        })
    });

    let suggested_positive = json
        .get("suggested_positive")
        .and_then(|v| v.as_str())
        .map(String::from);

    let suggested_negative = json
        .get("suggested_negative")
        .and_then(|v| v.as_str())
        .map(String::from);

    Ok(ParsedReviewer {
        approved,
        issues,
        suggested_positive,
        suggested_negative,
    })
}

pub(super) fn extract_json_from_text(text: &str) -> Result<Value> {
    // Try direct parse first
    if let Ok(json) = serde_json::from_str::<Value>(text.trim()) {
        return Ok(json);
    }

    // Strip <think>...</think> blocks (deepseek-r1, qwen3, etc.)
    let cleaned = strip_think_tags(text);
    let cleaned = cleaned.trim();

    // Try parsing the cleaned text directly
    if let Ok(json) = serde_json::from_str::<Value>(cleaned) {
        return Ok(json);
    }

    // Try extracting from markdown code blocks (```json ... ``` or ``` ... ```)
    if let Some(json) = extract_from_code_block(cleaned) {
        return Ok(json);
    }

    // Try to find JSON array or object by matching brackets
    for (start_char, end_char) in [('[', ']'), ('{', '}')] {
        // Try from the LAST occurrence of the start char to handle cases where
        // earlier text contains stray brackets
        if let Some(json) = find_balanced_json(cleaned, start_char, end_char) {
            return Ok(json);
        }
    }

    anyhow::bail!(
        "Could not extract valid JSON from LLM response: {}",
        &cleaned[..cleaned.len().min(300)]
    )
}

/// Strip `<think>...</think>` blocks that reasoning models emit
fn strip_think_tags(text: &str) -> String {
    let mut result = text.to_string();
    // Handle both <think>...</think> and incomplete <think>... without closing tag
    while let Some(start) = result.find("<think>") {
        if let Some(end) = result[start..].find("</think>") {
            result = format!("{}{}", &result[..start], &result[start + end + 8..]);
        } else {
            // No closing tag — strip from <think> to end of text
            result = result[..start].to_string();
            break;
        }
    }
    result
}

/// Extract JSON from markdown code blocks: ```json\n...\n``` or ```\n...\n```
fn extract_from_code_block(text: &str) -> Option<Value> {
    // Try ```json first, then plain ```
    for marker in ["```json", "```"] {
        let mut search_from = 0;
        while let Some(start) = text[search_from..].find(marker) {
            let abs_start = search_from + start + marker.len();
            // Skip to next line
            let content_start = text[abs_start..].find('\n').map(|p| abs_start + p + 1)?;
            if let Some(end) = text[content_start..].find("```") {
                let candidate = text[content_start..content_start + end].trim();
                if let Ok(json) = serde_json::from_str::<Value>(candidate) {
                    return Some(json);
                }
            }
            search_from = abs_start;
        }
    }
    None
}

/// Find valid JSON by trying all occurrences of start_char, paired with
/// each occurrence of end_char after it (preferring the tightest match)
fn find_balanced_json(text: &str, start_char: char, end_char: char) -> Option<Value> {
    let starts: Vec<usize> = text.match_indices(start_char).map(|(i, _)| i).collect();
    let ends: Vec<usize> = text.match_indices(end_char).map(|(i, _)| i).collect();

    // Try each start position, preferring later ones (more likely to be the actual JSON
    // rather than stray brackets in prose/thinking)
    for &start in starts.iter().rev() {
        for &end in ends.iter().rev() {
            if end <= start {
                continue;
            }
            let candidate = &text[start..=end];
            if let Ok(json) = serde_json::from_str::<Value>(candidate) {
                return Some(json);
            }
        }
    }
    None
}

#[cfg(test)]
#[path = "stages_test.rs"]
mod tests;
